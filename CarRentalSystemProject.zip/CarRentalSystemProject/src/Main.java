import model.*;
import service.*;

public class Main {
    public static void main(String[] args) {
        CarRentalSystem system = new CarRentalSystem();

        Vehicle car1 = new Vehicle("V001", "ABC123", "Civic", "Honda", 5);
        system.addVehicle(car1);

        Member member = new Member("M001", "Alice", "alice@mail.com");
        system.registerMember(member);

        // Search and reserve
        System.out.println("Available Civics: " + system.searchVehicle("Civic").size());
        system.reserveVehicle(member, car1);
        Notification.sendNotification(member, "Your vehicle reservation is confirmed!");

        // Check-out
        VehicleReservation reservation = member.getReservations().get(0);
        system.checkoutVehicle(reservation);

        // Add equipment, service, insurance
        reservation.addEquipment(new Equipment("GPS", 10));
        reservation.addService(new Service("WiFi", 5));
        reservation.setInsurance(new RentalInsurance("Full Coverage", 20));

        // Return vehicle
        system.returnVehicle(reservation);

        // Print all vehicle logs
        system.printLogs();
    }
}
